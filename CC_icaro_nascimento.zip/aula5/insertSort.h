#ifndef INSERTSORT_H_
#define INSERTSORT_H_

#include<stdio.h>
#include<stdlib.h>
#include"item.h"

void sort(Item *a, int lo, int hi);

#endif // !INSERTSORT_H_
#ifndef SELECTIONSORT_H_
#define SELECTIONSORT_H_

#include<stdio.h>
#include<stdlib.h>
#include"item.h"


void sort(Item *a, int lo, int hi);


#endif // !SELECTIONSORT_H_
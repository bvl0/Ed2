#ifndef SHAKERSORT_H_
#define SHAKERSORT_H_

#include<stdio.h>
#include<stdlib.h>
#include"item.h"

void sort(Item *a, int lo, int hi);
#endif // !SHAKERSORT_H_